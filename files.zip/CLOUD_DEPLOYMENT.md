# ☁️ MarketPulse Pro - Cloud Deployment Guide

## 🚀 Quick Start - Choose Your Platform

| Platform | Cost | Difficulty | Setup Time | Best For |
|----------|------|------------|------------|----------|
| **Railway** | $5/month | Easy ⭐ | 5 minutes | Beginners |
| **Heroku** | $7/month | Easy ⭐ | 10 minutes | Simple apps |
| **DigitalOcean** | $4-12/month | Medium ⭐⭐ | 30 minutes | Flexible |
| **AWS** | $5-15/month | Hard ⭐⭐⭐ | 60 minutes | Scalable |
| **Google Cloud** | $5-20/month | Hard ⭐⭐⭐ | 60 minutes | Enterprise |

## 🟢 Option 1: Railway (Recommended - Easiest)

**Why Railway?** Dead simple, great for beginners, automatic HTTPS, custom domains.

### Step 1: Prepare Your Code
```bash
# Create these files in your project directory
```

### Step 2: Create railway.toml
```toml
[build]
builder = "NIXPACKS"

[deploy]
startCommand = "gunicorn -w 4 -b 0.0.0.0:$PORT market_api_server:app"
healthcheckPath = "/api/status"
healthcheckTimeout = 300
restartPolicyType = "ON_FAILURE"

[variables]
PYTHON_VERSION = "3.11"
PORT = "5000"
```

### Step 3: Update requirements.txt
```txt
# Add gunicorn for production
Flask==3.0.2
Flask-CORS==4.0.0
yfinance==0.2.28
requests==2.31.0
aiohttp==3.9.3
pandas==2.2.1
numpy==1.26.4
python-dotenv==1.0.1
gunicorn==21.2.0
```

### Step 4: Deploy to Railway
```bash
# 1. Install Railway CLI
npm install -g @railway/cli
# or
curl -fsSL https://railway.app/install.sh | sh

# 2. Login to Railway
railway login

# 3. Initialize project
railway init

# 4. Deploy
railway up
```

### Step 5: Set Environment Variables
```bash
# Set your API keys (optional)
railway variables set ALPHA_VANTAGE_API_KEY=your_key_here
railway variables set TRADINGECONOMICS_API_KEY=your_key_here

# Set production settings
railway variables set FLASK_ENV=production
railway variables set CORS_ORIGINS=https://your-domain.railway.app
```

### Step 6: Custom Domain (Optional)
```bash
# Add your domain
railway domain add your-domain.com
```

**Your API will be live at: `https://your-project.railway.app/api/status`**

---

## 🔵 Option 2: Heroku (Classic Choice)

### Step 1: Create Procfile
```bash
# Create file named 'Procfile' (no extension)
web: gunicorn -w 4 -b 0.0.0.0:$PORT market_api_server:app
```

### Step 2: Create runtime.txt
```txt
python-3.11.8
```

### Step 3: Update market_api_server.py
```python
# Add this at the bottom of market_api_server.py
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False  # Always False in production
    )
```

### Step 4: Deploy to Heroku
```bash
# 1. Install Heroku CLI
# Download from: https://devcenter.heroku.com/articles/heroku-cli

# 2. Login
heroku login

# 3. Create app
heroku create marketpulse-pro-YOUR-NAME

# 4. Set environment variables
heroku config:set FLASK_ENV=production
heroku config:set ALPHA_VANTAGE_API_KEY=your_key_here

# 5. Deploy
git init
git add .
git commit -m "Initial deployment"
git push heroku main
```

**Your API will be live at: `https://marketpulse-pro-yourname.herokuapp.com/api/status`**

---

## 🟠 Option 3: DigitalOcean Droplet (More Control)

### Step 1: Create Droplet
1. Go to [DigitalOcean](https://digitalocean.com)
2. Create account, get $200 free credit
3. Create Droplet: Ubuntu 22.04, $4-12/month
4. Add SSH key or use password

### Step 2: Connect & Setup
```bash
# SSH into your droplet
ssh root@your_droplet_ip

# Update system
apt update && apt upgrade -y

# Install Python and dependencies
apt install python3 python3-pip nginx supervisor git -y

# Install your app
git clone YOUR_REPOSITORY_URL /opt/marketpulse
cd /opt/marketpulse

# Install Python packages
pip3 install -r requirements.txt

# Create systemd service
```

### Step 3: Create systemd service
```bash
# Create /etc/systemd/system/marketpulse.service
sudo nano /etc/systemd/system/marketpulse.service
```

```ini
[Unit]
Description=MarketPulse Pro API
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/marketpulse
Environment="PATH=/opt/marketpulse/venv/bin"
ExecStart=/opt/marketpulse/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 market_api_server:app
Restart=always

[Install]
WantedBy=multi-user.target
```

### Step 4: Configure Nginx
```bash
# Create /etc/nginx/sites-available/marketpulse
sudo nano /etc/nginx/sites-available/marketpulse
```

```nginx
server {
    listen 80;
    server_name your_domain.com www.your_domain.com;

    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location / {
        root /opt/marketpulse;
        index marketpulse_pro.html;
        try_files $uri $uri/ =404;
    }
}
```

### Step 5: Enable & Start Services
```bash
# Enable nginx site
sudo ln -s /etc/nginx/sites-available/marketpulse /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Start your app
sudo systemctl daemon-reload
sudo systemctl enable marketpulse
sudo systemctl start marketpulse

# Check status
sudo systemctl status marketpulse
```

### Step 6: SSL with Let's Encrypt
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate
sudo certbot --nginx -d your_domain.com -d www.your_domain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

---

## ⚡ Option 4: AWS (Most Scalable)

### Step 1: Create EC2 Instance
1. Login to AWS Console
2. Go to EC2 → Launch Instance
3. Choose Ubuntu 22.04 LTS
4. Instance type: t3.micro (free tier) or t3.small
5. Create key pair for SSH access
6. Security Group: Allow HTTP (80), HTTPS (443), SSH (22)

### Step 2: Setup Application
```bash
# Same as DigitalOcean steps 2-5
# SSH: ssh -i your_key.pem ubuntu@your_ec2_ip
```

### Step 3: Application Load Balancer (Optional)
```bash
# For high availability, create ALB
# Target multiple EC2 instances
# Auto-scaling group
# RDS for database (if needed)
```

### Step 4: Route 53 for Domain
1. Register domain in Route 53
2. Create hosted zone
3. Point to your ALB or EC2 IP

---

## 📊 Frontend Deployment Options

### Option A: Same Server (Simplest)
Your HTML files are served by the same server as the API.

### Option B: CDN Deployment (Faster)
Deploy frontend to CDN, API to server.

**Netlify (Free):**
```bash
# 1. Build static version of your HTML
# 2. Update API URLs to your deployed backend
# 3. Drag & drop to netlify.com
```

**Vercel (Free):**
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

**Cloudflare Pages (Free):**
```bash
# Connect GitHub repo
# Auto-deploy on push
```

---

## 🔧 Production Configuration

### Update market_api_server.py for Production
```python
import os
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)

# Production CORS configuration
CORS(app, origins=[
    'https://your-domain.com',
    'https://www.your-domain.com',
    'https://your-frontend.netlify.app'
])

# Production logging
import logging
if not app.debug:
    logging.basicConfig(level=logging.INFO)

# Production error handling
@app.errorhandler(Exception)
def handle_exception(e):
    app.logger.error(f"Unhandled exception: {e}")
    return jsonify({'error': 'Internal server error'}), 500
```

### Update Frontend API URLs
```javascript
// In marketpulse_pro.html, update API_CONFIG
const API_CONFIG = {
    baseUrl: 'https://your-api-domain.com/api',  // Update this!
    endpoints: {
        futures: '/futures',
        stocks: '/stocks',
        // ... rest stays the same
    },
    fallback: true
};
```

### Environment Variables for Production
```bash
# Required
FLASK_ENV=production
PORT=5000

# Optional API Keys
ALPHA_VANTAGE_API_KEY=your_key
TRADINGECONOMICS_API_KEY=your_key
MARKETSTACK_API_KEY=your_key

# Security
SECRET_KEY=your_secret_key_here
CORS_ORIGINS=https://your-domain.com,https://www.your-domain.com
```

---

## 🔍 Monitoring & Maintenance

### Health Checks
```bash
# Check if your API is running
curl https://your-domain.com/api/status

# Expected response:
{
  "status": "online",
  "timestamp": "2026-02-06T19:30:00Z",
  "version": "1.0"
}
```

### Log Monitoring
```bash
# View logs (systemd)
sudo journalctl -u marketpulse -f

# View logs (Railway)
railway logs

# View logs (Heroku)
heroku logs --tail
```

### Uptime Monitoring
- **Uptimerobot.com** (free) - monitors your API every 5 minutes
- **Pingdom** (paid) - more detailed monitoring
- **DataDog** (enterprise) - full application monitoring

### Automated Backups
```bash
# Backup your data daily
#!/bin/bash
# backup_script.sh
curl -s https://your-domain.com/api/refresh-all >> /var/log/market_backup_$(date +%Y%m%d).json

# Add to crontab: 0 2 * * * /path/to/backup_script.sh
```

---

## 💡 Cost Optimization

### Free Tier Options
- **Railway**: $0 for hobby projects (500 hours/month)
- **Heroku**: $0 for sleeping apps (550 hours/month)  
- **AWS**: $0 for 12 months (t2.micro instance)
- **Google Cloud**: $300 free credits

### Budget Deployment ($5-10/month)
- **Railway**: $5/month for always-on
- **DigitalOcean**: $4/month droplet
- **Hetzner**: €3/month VPS (Europe)

### Scaling Strategy
1. **Start**: Single server deployment
2. **Growth**: Load balancer + multiple instances  
3. **Scale**: Kubernetes cluster with auto-scaling

---

## 🚨 Security Checklist

- [ ] HTTPS enabled (SSL certificate)
- [ ] API keys in environment variables (not code)
- [ ] CORS properly configured
- [ ] Rate limiting implemented
- [ ] Regular security updates
- [ ] Firewall configured (only necessary ports open)
- [ ] Regular backups
- [ ] Monitoring and alerting set up

---

## 🎯 Recommended Quick Start

**For beginners: Railway**
1. Sign up at railway.app
2. Connect GitHub repo
3. Deploy with one click
4. Add environment variables
5. Get custom domain

**Total time: 10 minutes**  
**Cost: $5/month**  
**Result: Professional 24/7 market monitoring platform**

---

Ready to deploy your MarketPulse Pro platform to the cloud! Choose the option that fits your budget and technical comfort level. 🚀
